<?php
    $host_name = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'samuthrika';

    $conn = new mysqli($host_name, $db_user, $db_pass, $db_name);

    if($conn -> connect_error)
    {
        die('Connection Failed :' . $conn -> connect_error);
    }

    if(function_exists('date_default_timezone_set'))
    {
        date_default_timezone_set('Asia/Kolkata');
    }

    $dateTime = date('Y-m-d H:i:s');
    $date = date('Y-m-d');

    $path = '/samuthrika/';
?>